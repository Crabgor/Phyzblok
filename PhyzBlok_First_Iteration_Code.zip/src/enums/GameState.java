package enums;

/**
 * Created by Cregnacht on 2015-02-26.
 */
public enum GameState
{
    EXITING,
    LEVEL_SELECT,
    LOADING,
    MAIN_MENU,
    PAUSE,
    PLAY
}
