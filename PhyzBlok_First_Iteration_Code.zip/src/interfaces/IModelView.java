package interfaces;

import enums.GameState;

/**
 * Created by Cregnacht on 2015-03-04.
 */
public interface IModelView
{
    public void changeState(GameState state);
}
